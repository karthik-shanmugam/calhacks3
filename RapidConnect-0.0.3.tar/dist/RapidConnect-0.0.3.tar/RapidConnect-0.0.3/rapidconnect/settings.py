# -*- coding: utf-8 -*-
from __future__ import (print_function, unicode_literals, division, absolute_import)

DEFAULT_BASE_ENDPOINT = 'https://rapidapi.io/connect/'